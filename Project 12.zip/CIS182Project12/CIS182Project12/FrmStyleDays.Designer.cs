﻿namespace CIS182Project12
{
    partial class FrmStyleDays
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblYear = new System.Windows.Forms.Label();
            this.lblMake = new System.Windows.Forms.Label();
            this.lblModel = new System.Windows.Forms.Label();
            this.lblNumDoors = new System.Windows.Forms.Label();
            this.lblCostPerDay = new System.Windows.Forms.Label();
            this.lblLicenseNumber = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.txtLicenseNumber = new System.Windows.Forms.TextBox();
            this.txtMake = new System.Windows.Forms.TextBox();
            this.txtModel = new System.Windows.Forms.TextBox();
            this.txtNumDoors = new System.Windows.Forms.TextBox();
            this.txtCostPerDay = new System.Windows.Forms.TextBox();
            this.grpCarStyle = new System.Windows.Forms.GroupBox();
            this.rbtnLuxury = new System.Windows.Forms.RadioButton();
            this.rbtnStandard = new System.Windows.Forms.RadioButton();
            this.rbtnCompact = new System.Windows.Forms.RadioButton();
            this.grpNumDays = new System.Windows.Forms.GroupBox();
            this.rbtn7Days = new System.Windows.Forms.RadioButton();
            this.rbtn6Days = new System.Windows.Forms.RadioButton();
            this.rbtn5Days = new System.Windows.Forms.RadioButton();
            this.rbtn4Days = new System.Windows.Forms.RadioButton();
            this.rbtn3Days = new System.Windows.Forms.RadioButton();
            this.rbtn2Days = new System.Windows.Forms.RadioButton();
            this.rbtn1Day = new System.Windows.Forms.RadioButton();
            this.grpCarStyle.SuspendLayout();
            this.grpNumDays.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.Location = new System.Drawing.Point(12, 41);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(38, 17);
            this.lblYear.TabIndex = 0;
            this.lblYear.Text = "Year";
            // 
            // lblMake
            // 
            this.lblMake.AutoSize = true;
            this.lblMake.Location = new System.Drawing.Point(82, 41);
            this.lblMake.Name = "lblMake";
            this.lblMake.Size = new System.Drawing.Size(42, 17);
            this.lblMake.TabIndex = 1;
            this.lblMake.Text = "Make";
            // 
            // lblModel
            // 
            this.lblModel.AutoSize = true;
            this.lblModel.Location = new System.Drawing.Point(161, 41);
            this.lblModel.Name = "lblModel";
            this.lblModel.Size = new System.Drawing.Size(46, 17);
            this.lblModel.TabIndex = 2;
            this.lblModel.Text = "Model";
            // 
            // lblNumDoors
            // 
            this.lblNumDoors.AutoSize = true;
            this.lblNumDoors.Location = new System.Drawing.Point(269, 41);
            this.lblNumDoors.Name = "lblNumDoors";
            this.lblNumDoors.Size = new System.Drawing.Size(74, 17);
            this.lblNumDoors.TabIndex = 3;
            this.lblNumDoors.Text = "# of Doors";
            // 
            // lblCostPerDay
            // 
            this.lblCostPerDay.AutoSize = true;
            this.lblCostPerDay.Location = new System.Drawing.Point(204, 118);
            this.lblCostPerDay.Name = "lblCostPerDay";
            this.lblCostPerDay.Size = new System.Drawing.Size(91, 17);
            this.lblCostPerDay.TabIndex = 4;
            this.lblCostPerDay.Text = "Cost Per Day";
            // 
            // lblLicenseNumber
            // 
            this.lblLicenseNumber.AutoSize = true;
            this.lblLicenseNumber.Location = new System.Drawing.Point(9, 118);
            this.lblLicenseNumber.Name = "lblLicenseNumber";
            this.lblLicenseNumber.Size = new System.Drawing.Size(111, 17);
            this.lblLicenseNumber.TabIndex = 5;
            this.lblLicenseNumber.Text = "License Number";
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(64, 291);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 18;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(220, 291);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 17;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // txtYear
            // 
            this.txtYear.Location = new System.Drawing.Point(12, 61);
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(67, 22);
            this.txtYear.TabIndex = 1;
            // 
            // txtLicenseNumber
            // 
            this.txtLicenseNumber.Location = new System.Drawing.Point(117, 118);
            this.txtLicenseNumber.MaxLength = 7;
            this.txtLicenseNumber.Name = "txtLicenseNumber";
            this.txtLicenseNumber.Size = new System.Drawing.Size(81, 22);
            this.txtLicenseNumber.TabIndex = 5;
            // 
            // txtMake
            // 
            this.txtMake.Location = new System.Drawing.Point(85, 61);
            this.txtMake.Name = "txtMake";
            this.txtMake.Size = new System.Drawing.Size(73, 22);
            this.txtMake.TabIndex = 2;
            // 
            // txtModel
            // 
            this.txtModel.Location = new System.Drawing.Point(164, 61);
            this.txtModel.Name = "txtModel";
            this.txtModel.Size = new System.Drawing.Size(102, 22);
            this.txtModel.TabIndex = 3;
            // 
            // txtNumDoors
            // 
            this.txtNumDoors.Location = new System.Drawing.Point(272, 61);
            this.txtNumDoors.Name = "txtNumDoors";
            this.txtNumDoors.Size = new System.Drawing.Size(77, 22);
            this.txtNumDoors.TabIndex = 4;
            // 
            // txtCostPerDay
            // 
            this.txtCostPerDay.Location = new System.Drawing.Point(301, 118);
            this.txtCostPerDay.Name = "txtCostPerDay";
            this.txtCostPerDay.Size = new System.Drawing.Size(62, 22);
            this.txtCostPerDay.TabIndex = 6;
            // 
            // grpCarStyle
            // 
            this.grpCarStyle.Controls.Add(this.rbtnLuxury);
            this.grpCarStyle.Controls.Add(this.rbtnStandard);
            this.grpCarStyle.Controls.Add(this.rbtnCompact);
            this.grpCarStyle.Location = new System.Drawing.Point(55, 160);
            this.grpCarStyle.Name = "grpCarStyle";
            this.grpCarStyle.Size = new System.Drawing.Size(103, 107);
            this.grpCarStyle.TabIndex = 14;
            this.grpCarStyle.TabStop = false;
            this.grpCarStyle.Text = "Car Style";
            // 
            // rbtnLuxury
            // 
            this.rbtnLuxury.AutoSize = true;
            this.rbtnLuxury.Location = new System.Drawing.Point(9, 76);
            this.rbtnLuxury.Name = "rbtnLuxury";
            this.rbtnLuxury.Size = new System.Drawing.Size(71, 21);
            this.rbtnLuxury.TabIndex = 9;
            this.rbtnLuxury.Text = "Luxury";
            this.rbtnLuxury.UseVisualStyleBackColor = true;
            // 
            // rbtnStandard
            // 
            this.rbtnStandard.AutoSize = true;
            this.rbtnStandard.Location = new System.Drawing.Point(9, 48);
            this.rbtnStandard.Name = "rbtnStandard";
            this.rbtnStandard.Size = new System.Drawing.Size(87, 21);
            this.rbtnStandard.TabIndex = 8;
            this.rbtnStandard.Text = "Standard";
            this.rbtnStandard.UseVisualStyleBackColor = true;
            // 
            // rbtnCompact
            // 
            this.rbtnCompact.AutoSize = true;
            this.rbtnCompact.Checked = true;
            this.rbtnCompact.Location = new System.Drawing.Point(9, 21);
            this.rbtnCompact.Name = "rbtnCompact";
            this.rbtnCompact.Size = new System.Drawing.Size(84, 21);
            this.rbtnCompact.TabIndex = 7;
            this.rbtnCompact.TabStop = true;
            this.rbtnCompact.Text = "Compact";
            this.rbtnCompact.UseVisualStyleBackColor = true;
            // 
            // grpNumDays
            // 
            this.grpNumDays.Controls.Add(this.rbtn7Days);
            this.grpNumDays.Controls.Add(this.rbtn6Days);
            this.grpNumDays.Controls.Add(this.rbtn5Days);
            this.grpNumDays.Controls.Add(this.rbtn4Days);
            this.grpNumDays.Controls.Add(this.rbtn3Days);
            this.grpNumDays.Controls.Add(this.rbtn2Days);
            this.grpNumDays.Controls.Add(this.rbtn1Day);
            this.grpNumDays.Location = new System.Drawing.Point(164, 160);
            this.grpNumDays.Name = "grpNumDays";
            this.grpNumDays.Size = new System.Drawing.Size(166, 125);
            this.grpNumDays.TabIndex = 15;
            this.grpNumDays.TabStop = false;
            this.grpNumDays.Text = "Number of Days";
            // 
            // rbtn7Days
            // 
            this.rbtn7Days.AutoSize = true;
            this.rbtn7Days.Location = new System.Drawing.Point(7, 98);
            this.rbtn7Days.Name = "rbtn7Days";
            this.rbtn7Days.Size = new System.Drawing.Size(69, 21);
            this.rbtn7Days.TabIndex = 16;
            this.rbtn7Days.Text = "Seven";
            this.rbtn7Days.UseVisualStyleBackColor = true;
            // 
            // rbtn6Days
            // 
            this.rbtn6Days.AutoSize = true;
            this.rbtn6Days.Location = new System.Drawing.Point(95, 76);
            this.rbtn6Days.Name = "rbtn6Days";
            this.rbtn6Days.Size = new System.Drawing.Size(47, 21);
            this.rbtn6Days.TabIndex = 15;
            this.rbtn6Days.Text = "Six";
            this.rbtn6Days.UseVisualStyleBackColor = true;
            // 
            // rbtn5Days
            // 
            this.rbtn5Days.AutoSize = true;
            this.rbtn5Days.Location = new System.Drawing.Point(7, 76);
            this.rbtn5Days.Name = "rbtn5Days";
            this.rbtn5Days.Size = new System.Drawing.Size(55, 21);
            this.rbtn5Days.TabIndex = 14;
            this.rbtn5Days.Text = "Five";
            this.rbtn5Days.UseVisualStyleBackColor = true;
            // 
            // rbtn4Days
            // 
            this.rbtn4Days.AutoSize = true;
            this.rbtn4Days.Location = new System.Drawing.Point(95, 49);
            this.rbtn4Days.Name = "rbtn4Days";
            this.rbtn4Days.Size = new System.Drawing.Size(58, 21);
            this.rbtn4Days.TabIndex = 13;
            this.rbtn4Days.Text = "Four";
            this.rbtn4Days.UseVisualStyleBackColor = true;
            // 
            // rbtn3Days
            // 
            this.rbtn3Days.AutoSize = true;
            this.rbtn3Days.Location = new System.Drawing.Point(6, 49);
            this.rbtn3Days.Name = "rbtn3Days";
            this.rbtn3Days.Size = new System.Drawing.Size(67, 21);
            this.rbtn3Days.TabIndex = 12;
            this.rbtn3Days.Text = "Three";
            this.rbtn3Days.UseVisualStyleBackColor = true;
            // 
            // rbtn2Days
            // 
            this.rbtn2Days.AutoSize = true;
            this.rbtn2Days.Location = new System.Drawing.Point(95, 21);
            this.rbtn2Days.Name = "rbtn2Days";
            this.rbtn2Days.Size = new System.Drawing.Size(55, 21);
            this.rbtn2Days.TabIndex = 11;
            this.rbtn2Days.Text = "Two";
            this.rbtn2Days.UseVisualStyleBackColor = true;
            // 
            // rbtn1Day
            // 
            this.rbtn1Day.AutoSize = true;
            this.rbtn1Day.Checked = true;
            this.rbtn1Day.Location = new System.Drawing.Point(6, 21);
            this.rbtn1Day.Name = "rbtn1Day";
            this.rbtn1Day.Size = new System.Drawing.Size(56, 21);
            this.rbtn1Day.TabIndex = 10;
            this.rbtn1Day.TabStop = true;
            this.rbtn1Day.Text = "One";
            this.rbtn1Day.UseVisualStyleBackColor = true;
            // 
            // FrmStyleDays
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(375, 326);
            this.Controls.Add(this.grpNumDays);
            this.Controls.Add(this.grpCarStyle);
            this.Controls.Add(this.txtCostPerDay);
            this.Controls.Add(this.txtNumDoors);
            this.Controls.Add(this.txtModel);
            this.Controls.Add(this.txtMake);
            this.Controls.Add(this.txtLicenseNumber);
            this.Controls.Add(this.txtYear);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblLicenseNumber);
            this.Controls.Add(this.lblCostPerDay);
            this.Controls.Add(this.lblNumDoors);
            this.Controls.Add(this.lblModel);
            this.Controls.Add(this.lblMake);
            this.Controls.Add(this.lblYear);
            this.Name = "FrmStyleDays";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Style Days";
            this.grpCarStyle.ResumeLayout(false);
            this.grpCarStyle.PerformLayout();
            this.grpNumDays.ResumeLayout(false);
            this.grpNumDays.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.Label lblMake;
        private System.Windows.Forms.Label lblModel;
        private System.Windows.Forms.Label lblNumDoors;
        private System.Windows.Forms.Label lblCostPerDay;
        private System.Windows.Forms.Label lblLicenseNumber;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.TextBox txtLicenseNumber;
        private System.Windows.Forms.TextBox txtMake;
        private System.Windows.Forms.TextBox txtModel;
        private System.Windows.Forms.TextBox txtNumDoors;
        private System.Windows.Forms.TextBox txtCostPerDay;
        private System.Windows.Forms.GroupBox grpCarStyle;
        private System.Windows.Forms.RadioButton rbtnLuxury;
        private System.Windows.Forms.RadioButton rbtnStandard;
        private System.Windows.Forms.RadioButton rbtnCompact;
        private System.Windows.Forms.GroupBox grpNumDays;
        private System.Windows.Forms.RadioButton rbtn7Days;
        private System.Windows.Forms.RadioButton rbtn6Days;
        private System.Windows.Forms.RadioButton rbtn5Days;
        private System.Windows.Forms.RadioButton rbtn4Days;
        private System.Windows.Forms.RadioButton rbtn3Days;
        private System.Windows.Forms.RadioButton rbtn2Days;
        private System.Windows.Forms.RadioButton rbtn1Day;
    }
}

