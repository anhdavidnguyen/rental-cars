﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS182Project12
{
    public partial class FrmStyleDays : Form
    {
        private RentalCarAgreement car;

        /// <summary>
        /// Initialize the form for styling a car
        /// </summary>
        public FrmStyleDays()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Initialize the form for updating a car
        /// </summary>
        public FrmStyleDays(RentalCarAgreement car)
        {
            InitializeComponent();

            // Load current car data to form
            txtYear.Text = car.Year.ToString();
            txtMake.Text = car.Make;
            txtModel.Text = car.Model;
            txtLicenseNumber.Text = car.LicenseNumber;
            txtNumDoors.Text = car.NumDoors.ToString();
            txtCostPerDay.Text = car.CostPerDay.ToString();

            if (car.Style.Equals(rbtnCompact.Text))
                rbtnCompact.Checked = true;
            else if (car.Style.Equals(rbtnStandard.Text))
                rbtnStandard.Checked = true;
            else if (car.Style.Equals(rbtnLuxury.Text))
                rbtnLuxury.Checked = true;

            if (car.NumDays == 1)
                rbtn1Day.Checked = true;
            else if (car.NumDays == 2)
                rbtn2Days.Checked = true;
            else if (car.NumDays == 3)
                rbtn3Days.Checked = true;
            else if (car.NumDays == 4)
                rbtn4Days.Checked = true;
            else if (car.NumDays == 5)
                rbtn5Days.Checked = true;
            else if (car.NumDays == 6)
                rbtn6Days.Checked = true;
            else if (car.NumDays == 7)
                rbtn7Days.Checked = true;
        }

        /// <summary>
        /// Access to the created car object on this form
        /// </summary>
        public RentalCarAgreement Car
        {
            get
            {
                return car;
            }
        }

        /// <summary>
        /// Close the dialog
        /// </summary>
        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
            Close();
        }

        /// <summary>
        /// Validate and create the car object
        /// </summary>
        private void btnOK_Click(object sender, EventArgs e)
        {
            // Make sure all fields are provided
            if(txtYear.Text.Trim() == string.Empty
                || txtMake.Text.Trim() == string.Empty
                || txtModel.Text.Trim() == string.Empty
                || txtNumDoors.Text.Trim() == string.Empty
                || txtLicenseNumber.Text.Trim() == string.Empty
                || txtCostPerDay.Text.Trim() == string.Empty)
            {
                MessageBox.Show("All fields are required.", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate license number to have letter and numbers only
            string licenseNumber = txtLicenseNumber.Text.Trim();

            for(int i = 0; i < licenseNumber.Length; i++)
            {
                if (licenseNumber[i] >= 'A' && licenseNumber[i] <= 'Z')
                    continue;

                if (licenseNumber[i] >= '0' && licenseNumber[i] <= '9')
                    continue;

                MessageBox.Show("License number should be all upper case letters and numbers only.", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate the year
            double year;

            if(!double.TryParse(txtYear.Text.Trim(), out year))
            {
                MessageBox.Show("Year should be a decimal value.", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate the number of doors
            int numDoors;

            if(!int.TryParse(txtNumDoors.Text.Trim(), out numDoors))
            {
                MessageBox.Show("The number of doors should be an integer value.", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate the cost per day
            double costPerDay;

            if(!double.TryParse(txtCostPerDay.Text.Trim(), out costPerDay))
            {
                MessageBox.Show("The cost per day should be a decimal value.", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Get the style
            string style = "";

            if(rbtnCompact.Checked)
                style = rbtnCompact.Text;
            else if(rbtnStandard.Checked)
                style = rbtnStandard.Text;
            else if(rbtnLuxury.Checked)
                style = rbtnLuxury.Text;

            // Get the number of days
            int numDays = 0;

            if(rbtn1Day.Checked)
                numDays = 1;
            else if(rbtn2Days.Checked)
                numDays = 2;
            else if(rbtn3Days.Checked)
                numDays = 3;
            else if(rbtn4Days.Checked)
                numDays = 4;
            else if(rbtn5Days.Checked)
                numDays = 5;
            else if(rbtn6Days.Checked)
                numDays = 6;
            else if(rbtn7Days.Checked)
                numDays = 7;

            if (car == null)
            {
                // Create the car if valid
                try
                {
                    car = new RentalCarAgreement(year, txtMake.Text.Trim(), txtModel.Text.Trim(), 
                        numDoors, style, costPerDay, txtLicenseNumber.Text.Trim(), numDays);

                    DialogResult = System.Windows.Forms.DialogResult.OK;
                    Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Notification", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                // Update the car if valid
                try
                {
                    car.Year = year;
                    car.Make = txtMake.Text.Trim();
                    car.Model = txtModel.Text.Trim();
                    car.NumDoors = numDoors;
                    car.Style = style;
                    car.CostPerDay = costPerDay;
                    car.LicenseNumber = txtLicenseNumber.Text.Trim();
                    car.NumDays = numDays;

                    DialogResult = System.Windows.Forms.DialogResult.OK;
                    Close();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message, "Notification", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
