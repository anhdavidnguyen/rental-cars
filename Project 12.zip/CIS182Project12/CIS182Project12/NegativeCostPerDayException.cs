﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIS182Project12
{
    public class NegativeCostPerDayException
        : Exception
    {
        /// <summary>
        /// Create the exception
        /// </summary>
        public NegativeCostPerDayException()
            : base("The cost per day can not be less than zero.")
        {
        }
    }
}
