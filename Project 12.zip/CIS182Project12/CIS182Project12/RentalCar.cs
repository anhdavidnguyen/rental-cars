﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIS182Project12
{
    /// <summary>
    /// A car that can be rented
    /// </summary>
    public class RentalCar 
        : Car
    {
        private string style;
        private double costPerDay;
        private string licenseNumber;

        /// <summary>
        /// Create a rental car
        /// </summary>
        public RentalCar(double year, string make, string model, int numDoors, string style, double costPerDay, string licenseNumber)
            : base(year, make, model, numDoors)
        {
            this.style = style;
            this.costPerDay = costPerDay;
            this.licenseNumber = licenseNumber;

            if (costPerDay <= 0)
                throw new NegativeCostPerDayException();
        }

        /// <summary>
        /// Return a string representation of a rental car
        /// </summary>
        public override string ToString()
        {
            return licenseNumber;
        }

        /// <summary>
        /// Access/mutator ro the license number property
        /// </summary>
        public string LicenseNumber
        {
            get
            {
                return licenseNumber;
            }
            set
            {
                licenseNumber = value;
            }
        }

        /// <summary>
        /// Accessor/mutator to the cost per day property
        /// </summary>
        public double CostPerDay
        {
            get
            {
                return costPerDay;
            }
            set
            {
                if (value < 0)
                    throw new NegativeCostPerDayException();

                costPerDay = value;
            }
        }

        /// <summary>
        /// Accessor/mutator to the style property
        /// </summary>
        public string Style
        {
            get
            {
                return style;
            }
            set
            {
                style = value;
            }
        }
    }
}
