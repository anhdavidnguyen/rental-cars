﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIS182Project12
{
    public class RentalCarAgreement
        : RentalCar
    {
        private int numDays;

        /// <summary>
        /// Create a rental car agreement
        /// </summary>
        public RentalCarAgreement(double year, string make, string model, int numDoors, string style, double costPerDay, string licenseNumber, int numDays)
            : base(year, make, model, numDoors, style, costPerDay, licenseNumber)
        {
            this.numDays = numDays;
        }

        /// <summary>
        /// Accessor/mutator to the number of days property
        /// </summary>
        public int NumDays
        {
            get
            {
                return numDays;
            }
            set
            {
                numDays = value;
            }
        }
    }
}
