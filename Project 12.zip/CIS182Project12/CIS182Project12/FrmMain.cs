﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS182Project12
{
    public partial class FrmMain : Form
    {
        /// <summary>
        /// Initialize the user interface
        /// </summary>
        public FrmMain()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Close the program
        /// </summary>
        private void btnExit_Click(object sender, EventArgs e)
        {
            Close(); 
        }

        /// <summary>
        /// Show the window for adding a new car
        /// </summary>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            FrmStyleDays styleDays = new FrmStyleDays();

            if (styleDays.ShowDialog() == System.Windows.Forms.DialogResult.Cancel)
                return;

            // Get the new car and add it the list if created
            lstCars.Items.Add(styleDays.Car);
        }

        /// <summary>
        /// Display the selected car to the user interface
        /// </summary>
        private void lstCars_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstCars.SelectedIndex == -1)
            {
                // Clear the fields if nothing is selected
                txtYear.Clear();
                txtModel.Clear();
                txtLicenseNumber.Clear();
                txtCostPerDay.Clear();
                txtStyle.Clear();
                txtNumDays.Clear();
                return;
            }

            RentalCarAgreement car = lstCars.SelectedItem as RentalCarAgreement;
            txtYear.Text = car.Year.ToString();
            txtModel.Text = car.Model;
            txtLicenseNumber.Text = car.LicenseNumber;
            txtCostPerDay.Text = car.CostPerDay.ToString();
            txtStyle.Text = car.Style;
            txtNumDays.Text = car.NumDays.ToString();
        }

        /// <summary>
        /// Delete the selected car in the list
        /// </summary>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (lstCars.SelectedIndex == -1)
                return;

            lstCars.Items.RemoveAt(lstCars.SelectedIndex);
        }

        /// <summary>
        /// Show the form for editing the selected car
        /// </summary>
        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (lstCars.SelectedIndex == -1)
                return;

            FrmStyleDays styleDays = new FrmStyleDays(lstCars.SelectedItem as RentalCarAgreement);

            if (styleDays.ShowDialog() == System.Windows.Forms.DialogResult.Cancel)
                return;

            lstCars.Items[lstCars.SelectedIndex] = styleDays.Car;
        }
    }
}

/* David Nguyen
What concepts did you find challenging about this program? (Please be specific) 
The concept of inheritance is simple but the implementation 
takes awhile to learn but I got used to it as I continue to practice.
 
What did you learn in this program? (Please be specific) 
I learned how to understand the purpose of inheritance and pass around
objects from one form to another.
*/