﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIS182Project12
{
    /// <summary>
    /// Hold car properties
    /// </summary>
    public class Car
    {
        private double year;
        private string make;
        private string model;
        private int numDoors;

        /// <summary>
        /// Create a new car
        /// </summary>
        public Car(double year, string make, string model, int numDoors)
        {
            this.year = year;
            this.make = make;
            this.model = model;
            this.numDoors = numDoors;
        }

        /// <summary>
        /// Accessor/mutator to the number of doors property
        /// </summary>
        public int NumDoors
        {
            get
            {
                return numDoors;
            }
            set
            {
                numDoors = value;
            }
        }

        /// <summary>
        /// Accessor/mutator to the model property
        /// </summary>
        public string Model
        {
            get
            {
                return model;
            }
            set
            {
                model = value;
            }
        }

        /// <summary>
        /// Accessor/mutator to the make property
        /// </summary>
        public string Make
        {
            get
            {
                return make;
            }
            set
            {
                make = value;
            }
        }

        /// <summary>
        /// Accessor/mutator to the year property
        /// </summary>
        public double Year
        {
            get
            {
                return year;
            }
            set
            {
                year = value;
            }
        }
    }
}
