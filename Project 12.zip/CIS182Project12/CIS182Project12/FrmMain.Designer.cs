﻿namespace CIS182Project12
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblYear = new System.Windows.Forms.Label();
            this.lblModel = new System.Windows.Forms.Label();
            this.nseNum = new System.Windows.Forms.Label();
            this.lblCostPerDay = new System.Windows.Forms.Label();
            this.lblStyle = new System.Windows.Forms.Label();
            this.lblNumofDays = new System.Windows.Forms.Label();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lstCars = new System.Windows.Forms.ListBox();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.txtModel = new System.Windows.Forms.TextBox();
            this.txtLicenseNumber = new System.Windows.Forms.TextBox();
            this.txtCostPerDay = new System.Windows.Forms.TextBox();
            this.txtStyle = new System.Windows.Forms.TextBox();
            this.txtNumDays = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.Location = new System.Drawing.Point(61, 18);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(38, 17);
            this.lblYear.TabIndex = 0;
            this.lblYear.Text = "Year";
            // 
            // lblModel
            // 
            this.lblModel.AutoSize = true;
            this.lblModel.Location = new System.Drawing.Point(58, 63);
            this.lblModel.Name = "lblModel";
            this.lblModel.Size = new System.Drawing.Size(46, 17);
            this.lblModel.TabIndex = 1;
            this.lblModel.Text = "Model";
            // 
            // nseNum
            // 
            this.nseNum.AutoSize = true;
            this.nseNum.Location = new System.Drawing.Point(30, 109);
            this.nseNum.Name = "nseNum";
            this.nseNum.Size = new System.Drawing.Size(111, 17);
            this.nseNum.TabIndex = 2;
            this.nseNum.Text = "License Number";
            // 
            // lblCostPerDay
            // 
            this.lblCostPerDay.AutoSize = true;
            this.lblCostPerDay.Location = new System.Drawing.Point(39, 154);
            this.lblCostPerDay.Name = "lblCostPerDay";
            this.lblCostPerDay.Size = new System.Drawing.Size(91, 17);
            this.lblCostPerDay.TabIndex = 3;
            this.lblCostPerDay.Text = "Cost Per Day";
            // 
            // lblStyle
            // 
            this.lblStyle.AutoSize = true;
            this.lblStyle.Location = new System.Drawing.Point(58, 199);
            this.lblStyle.Name = "lblStyle";
            this.lblStyle.Size = new System.Drawing.Size(39, 17);
            this.lblStyle.TabIndex = 4;
            this.lblStyle.Text = "Style";
            // 
            // lblNumofDays
            // 
            this.lblNumofDays.AutoSize = true;
            this.lblNumofDays.Location = new System.Drawing.Point(30, 245);
            this.lblNumofDays.Name = "lblNumofDays";
            this.lblNumofDays.Size = new System.Drawing.Size(110, 17);
            this.lblNumofDays.TabIndex = 5;
            this.lblNumofDays.Text = "Number of Days";
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(162, 187);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 23);
            this.btnEdit.TabIndex = 6;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(162, 221);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 7;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(162, 151);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 8;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(162, 255);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 9;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lstCars
            // 
            this.lstCars.FormattingEnabled = true;
            this.lstCars.ItemHeight = 16;
            this.lstCars.Location = new System.Drawing.Point(251, 18);
            this.lstCars.Name = "lstCars";
            this.lstCars.Size = new System.Drawing.Size(210, 260);
            this.lstCars.TabIndex = 10;
            this.lstCars.SelectedIndexChanged += new System.EventHandler(this.lstCars_SelectedIndexChanged);
            // 
            // txtYear
            // 
            this.txtYear.Location = new System.Drawing.Point(33, 38);
            this.txtYear.Name = "txtYear";
            this.txtYear.ReadOnly = true;
            this.txtYear.Size = new System.Drawing.Size(105, 22);
            this.txtYear.TabIndex = 11;
            // 
            // txtModel
            // 
            this.txtModel.Location = new System.Drawing.Point(33, 83);
            this.txtModel.Name = "txtModel";
            this.txtModel.ReadOnly = true;
            this.txtModel.Size = new System.Drawing.Size(105, 22);
            this.txtModel.TabIndex = 12;
            // 
            // txtLicenseNumber
            // 
            this.txtLicenseNumber.Location = new System.Drawing.Point(33, 129);
            this.txtLicenseNumber.Name = "txtLicenseNumber";
            this.txtLicenseNumber.ReadOnly = true;
            this.txtLicenseNumber.Size = new System.Drawing.Size(105, 22);
            this.txtLicenseNumber.TabIndex = 13;
            // 
            // txtCostPerDay
            // 
            this.txtCostPerDay.Location = new System.Drawing.Point(33, 174);
            this.txtCostPerDay.Name = "txtCostPerDay";
            this.txtCostPerDay.ReadOnly = true;
            this.txtCostPerDay.Size = new System.Drawing.Size(105, 22);
            this.txtCostPerDay.TabIndex = 14;
            // 
            // txtStyle
            // 
            this.txtStyle.Location = new System.Drawing.Point(33, 221);
            this.txtStyle.Name = "txtStyle";
            this.txtStyle.ReadOnly = true;
            this.txtStyle.Size = new System.Drawing.Size(105, 22);
            this.txtStyle.TabIndex = 15;
            // 
            // txtNumDays
            // 
            this.txtNumDays.Location = new System.Drawing.Point(33, 266);
            this.txtNumDays.Name = "txtNumDays";
            this.txtNumDays.ReadOnly = true;
            this.txtNumDays.Size = new System.Drawing.Size(105, 22);
            this.txtNumDays.TabIndex = 16;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(473, 305);
            this.Controls.Add(this.txtNumDays);
            this.Controls.Add(this.txtStyle);
            this.Controls.Add(this.txtCostPerDay);
            this.Controls.Add(this.txtLicenseNumber);
            this.Controls.Add(this.txtModel);
            this.Controls.Add(this.txtYear);
            this.Controls.Add(this.lstCars);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.lblNumofDays);
            this.Controls.Add(this.lblStyle);
            this.Controls.Add(this.lblCostPerDay);
            this.Controls.Add(this.nseNum);
            this.Controls.Add(this.lblModel);
            this.Controls.Add(this.lblYear);
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rental Car Agreement -ADN";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.Label lblModel;
        private System.Windows.Forms.Label nseNum;
        private System.Windows.Forms.Label lblCostPerDay;
        private System.Windows.Forms.Label lblStyle;
        private System.Windows.Forms.Label lblNumofDays;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.ListBox lstCars;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.TextBox txtModel;
        private System.Windows.Forms.TextBox txtLicenseNumber;
        private System.Windows.Forms.TextBox txtCostPerDay;
        private System.Windows.Forms.TextBox txtStyle;
        private System.Windows.Forms.TextBox txtNumDays;
    }
}